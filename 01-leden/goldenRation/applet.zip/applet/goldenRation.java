import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class goldenRation extends PApplet {

// kof strikes your brain 2011 by golden ratios

ArrayList pos = new ArrayList(0);

float G = (sqrt(5) + 1) / 2.0f;
float g = (sqrt(5) - 1) / 2.0f;

float A;
float X,Y;

float L = 1;



float H = 300;
float W = H*G;

boolean neg = false;

public void setup() {
  size((int)W,(int)H,P2D);
  A = H;
  X = Y = 0;

  noFill();
  stroke(255,35);
  
  smooth();
  
  
}


public void draw() {

  
  if(frameCount%4==0){
    neg = !neg;
  }
  
  if(neg){
  background(0);
  
    stroke(255,35); 
  }else{
background(255);
  
    stroke(0,35); 
    
  }
  //for(int i = 0 ;i< 10;i++){
  spiral( W*g, H*g, 0, 1000);
  spiral( width-W*g, H*g, 0, 1000);
  
  spiral( width-W*g, height-H*g, 0, 1000);
  spiral( W*g, height-H*g, 0, 1000);
  
  //}
  
  frame();
  
}

public void frame(){
 pushStyle();
 strokeWeight(6);
 noFill();
 stroke(0);
 rect(0,0,width,height);
popStyle(); 
  
}

public void spiral(float x,float y,float start,int many){
 X = x;
  Y = y;
  L = start;

  pushMatrix();
  for(int i = 1;i<many;i++) {

    translate(X,Y);
    rotate(radians(noise((frameCount-i)*0.001f*g)*60.0f+459));


    line(L,0,0,0);
    translate(-X,-Y);
    L+=g;
    X+=L;
  }
  popMatrix(); 
  
}

public void keyPressed(){
 println(mouseX); 
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--hide-stop", "goldenRation" });
  }
}
